# 01
# Escreva um programa que leia do teclado os valores da altura e do comprimento
# de um rectângulo e apresente no ecrã o seu perímetro e a sua área.

# Leitura
print("Dimensões do rectângulo:")
altura = float(input("\tAltura: "))
comprimento = float(input("\tComprimento: "))

# Cálculo
print("Os valores cálculados são:\n")
print("\t\tPerímetro - %.1f" % (2 * (altura + comprimento)))
print("\t\tÁrea - %.1f" % (altura * comprimento))