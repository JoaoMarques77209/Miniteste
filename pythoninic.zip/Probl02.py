# 02
# Escreva um programa que leia valores de velocidades em Km/h e os converta para m/s.

# Leitura
velocidade = float(input("Velocidade em km/h: "))

# Cálculo
print("Velocidade em m/s: %.2f" % (velocidade / 3.6))
