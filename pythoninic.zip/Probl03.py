# 03
# Escreva um programa que leia valores de temperatura em °Fahrenheit e os converta para °Celsius.
# nota: °Celsius = (°Fahrenheit – 32) / 1,80

# Leitura
temperatura = float(input("Tempertura em °F: "))

# Cálculo
print("Temperatura em °C: %.2f" % ((temperatura - 32)/1.8))
