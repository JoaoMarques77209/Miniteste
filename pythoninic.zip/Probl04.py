# 04
# Escreva um programa que leia valores de horas no formato horas:minutos:segundos
# e os converta para segundos.
#
# Exemplo:
# 11:22:14  → 40934 segundos

# Leitura
tempo = input("Horas -> ")
# Conversão
hora, minuto, segundo = tempo.split(":")
hora = int(hora); minuto = int(minuto); segundo = int(segundo)
print("Hora: %2d; Minuto: %2d; Segundo: %2d" % (hora, minuto, segundo))

#Calculo
print("O instante de tempo %2d:%2d:%2d corresponde a %d segundos!" % (hora, minuto, segundo, hora*3600 + minuto* 60 + segundo))