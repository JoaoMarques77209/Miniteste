# 05
# Um aluno sujeita-se a um exame. Escreva um programa para apresentar no ecrã
# a classificação qualitativa dessa nota (valor inteiro) segundo os seguintes níveis:

# 0 <= nota < 8 : mau; 
# 8 <= nota < 10 : insuficiente; 
# 10 <= nota < 14 : suficiente; 
# 14 <= nota < 18 : bom; 
# 18 <= nota <= 20 : excelente.

# nota: o valor da nota do aluno deve ser introduzido através do teclado e pertencer ao intervalo [0,20].


# Leitura
Nota = int(input("Classificação -> "))
# Seleção
while Nota < 0 or Nota > 20:
    Nota = int(input("Classificação incorreta!\n Classificação [0, 20] -> "))

if Nota < 8:
    print("Classificação de mau!")
elif Nota < 10:
    print("Classificação de insuficiente!")
elif Nota < 14:
    print("Classificação de suficiente!")
elif Nota < 18:
    print("Classificação de bom!")
else:
    print("Classificação de excelente!")